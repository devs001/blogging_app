<!--
如果你不认真勾选下面的内容，我可能会直接关闭你的 Issue。
提问之前，建议先阅读 https://github.com/ruby-china/How-To-Ask-Questions-The-Smart-Way
-->

**我确定我已经查看了** (标注`[ ]`为`[x]`)

- [ ] [DjangoBlog的readme](https://github.com/liangliangyy/DjangoBlog/blob/master/README.md)
- [ ] [配置说明](https://github.com/liangliangyy/DjangoBlog/blob/master/bin/config.md)
- [ ] [其他 Issues](https://github.com/liangliangyy/DjangoBlog/issues)

----

**我要申请**  (标注`[ ]`为`[x]`)

- [ ] BUG 反馈
- [ ] 添加新的特性或者功能
- [ ] 请求技术支持
